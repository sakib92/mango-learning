package com.appspot.mangolearning.server;

import com.appspot.mangolearning.client.RequestScoresService;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class RequestScoresServiceImpl extends RemoteServiceServlet implements RequestScoresService {

	@Override
	public String getScores(String property, String username) {
		DatastoreService ds = DatastoreServiceFactory.getDatastoreService();
		com.google.appengine.api.datastore.Key key = KeyFactory.createKey("User", username);
		try{
			Entity user = ds.get(key);
			return (String)user.getProperty(property);
		}catch(Exception ex){
			System.out.println("Something bad happened in server service when getting the high score");
			return null;
		}
	}

}
