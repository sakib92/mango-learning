package com.appspot.mangolearning.server;

import java.util.Date;

import com.appspot.mangolearning.client.LoginService;
import com.appspot.mangolearning.client.RegisterService;
import com.appspot.mangolearning.client.User;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class RegisterServiceImpl extends RemoteServiceServlet implements RegisterService{

	@Override
	public User register(User newUser) {
		DatastoreService ds = DatastoreServiceFactory.getDatastoreService();
		try{
			com.google.appengine.api.datastore.Key key = KeyFactory.createKey("User", newUser.getUsername());
			Entity user = ds.get(key);
			return null;
		}catch(Exception ex){
			Entity user = new Entity("User", newUser.getUsername());
			user.setProperty("Password", newUser.getPassword());
			user.setProperty("FirstName", newUser.getFirstName());
			user.setProperty("LastName", newUser.getLastName());
			user.setProperty("Gender", newUser.getGender());
			user.setProperty("Date", "-1");
			
//			user.setProperty("AdditionMadness","430|230|40");
//			user.setProperty("SubtractionFrenzy","2000|500|230");
//			user.setProperty("MultiplicationStorm","2300|300|60");
//			user.setProperty("DivisionDisaster","540|320|50");
//			user.setProperty("ChalkboardChallenger","10|5|1");
//			
			ds.put(user);
			return newUser;
		}
	}



}
