package com.appspot.mangolearning.server;

import com.appspot.mangolearning.client.LoginService;
import com.appspot.mangolearning.client.User;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class LoginServiceImpl extends RemoteServiceServlet implements LoginService{

	@Override
	public User login(String username, String password) {
		
		DatastoreService ds = DatastoreServiceFactory.getDatastoreService();
//		Entity e = new Entity("User", "username");
//		e.setProperty("AdditionMadness","430|230|40");
//		e.setProperty("SubtractionFrenzy","2000|500|230");
//		e.setProperty("MultiplicationStorm","2300|300|60");
//		e.setProperty("DivisionDisaster","540|320|50");
//		e.setProperty("ChalkboardChallenger","10|5|1");
//		ds.put(e);
		try{
			System.out.println("server: " + username);
			System.out.println("server: " + password);
			com.google.appengine.api.datastore.Key key = KeyFactory.createKey("User", username);
			Entity user = ds.get(key);
		
			if(user.getProperty("Password").equals(password))//TESTING PASSWORD
			{
				User u = new User();
				u.setFirstName((String)user.getProperty("FirstName"));
				u.setLastName((String)user.getProperty("LastName"));
				u.setUsername(user.getKey().toString());
				u.setPassword((String)user.getProperty("Password"));
				u.setGender((String)user.getProperty("Gender"));
				u.setDate((String)user.getProperty("Date"));
				return u;
			}
			else 
				return null;
		
		}
		catch(Exception ex){
			System.out.println("Server: Exception Thrown");
			return null;
		}
	}

}
