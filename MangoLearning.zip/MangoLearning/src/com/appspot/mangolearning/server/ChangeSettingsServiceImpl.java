package com.appspot.mangolearning.server;

import com.appspot.mangolearning.client.ChangeSettingsService;
import com.appspot.mangolearning.client.User;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class ChangeSettingsServiceImpl extends RemoteServiceServlet implements ChangeSettingsService{

	@Override
	public Boolean changeSettings(User u) {
		DatastoreService ds = DatastoreServiceFactory.getDatastoreService();
		System.out.println("Server: We are getting the user: " + u.getUsername());
		System.out.println("Server: lastname: " + u.getLastName());
		com.google.appengine.api.datastore.Key key = KeyFactory.createKey("User", u.getUsername());
		
		try {
			Entity user = ds.get(key);
			user.setProperty("FirstName", u.getFirstName());
			user.setProperty("LastName", u.getLastName());
			user.setProperty("Password", u.getPassword());
			user.setProperty("Gender", u.getGender());
			ds.put(user);
			return true;
		} catch (EntityNotFoundException e) {
			e.printStackTrace();
			return false;
			
		}
		
	}

}
