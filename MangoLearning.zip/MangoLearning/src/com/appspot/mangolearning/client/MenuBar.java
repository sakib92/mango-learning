package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.storage.client.Storage;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

public class MenuBar extends Composite {

	private static MenuBarUiBinder uiBinder = GWT.create(MenuBarUiBinder.class);

	interface MenuBarUiBinder extends UiBinder<Widget, MenuBar> {
	}

	AppController ac;
	@UiField
	Button accBtn;
	@UiField
	Button homeBtn;
	@UiField
	Button logoutBtn;
	@UiField
	Button gamesBtn;
	@UiField
	Button achievementBtn;

	public MenuBar(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac = appCont;

	}

	@UiHandler("logoutBtn")
	void handleLogout(ClickEvent e) {
		ac.reset();
		ac.setUpStartPage();
		ac.changeScreen(0);
		ac.displayHomeScreenMenu(false);
	}

	@UiHandler("accBtn")
	void handleViewAccountInfo(ClickEvent e) {
		ac.removeGame();
		ac.setAccInfo();
		ac.changeScreen(2);
	}

	@UiHandler("homeBtn")
	void handleHomeButton(ClickEvent e) {
		ac.removeGame();
		ac.setUpHomePage();
		ac.changeScreen(1);
	}

	@UiHandler("gamesBtn")
	void handleViewGames(ClickEvent e) {
		ac.removeGame();
		ac.changeScreen(4);
		//CHANGE
		ac.getStorage().clear();
	}

	@UiHandler("achievementBtn")
	void handleViewAchievement(ClickEvent e) {
//		String key="";
//		Storage stockStore = ac.getStorage();
//		  for (int i = 0; i < stockStore.getLength(); i++){
//			    key = stockStore.key(i);
//		  }
//		  
//		  System.out.println("Length: " +stockStore.getLength());
//		  System.out.println(key  + " " + stockStore.getItem(key));

		ac.removeGame();
		ac.changeScreen(5);
	}
}
