package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

public class FullMembershipPage extends Composite {

	private static FullMembershipPageUiBinder uiBinder = GWT
			.create(FullMembershipPageUiBinder.class);

	interface FullMembershipPageUiBinder extends
			UiBinder<Widget, FullMembershipPage> {
	}

	AppController ac;
	
	public FullMembershipPage(AppController ac) {
		initWidget(uiBinder.createAndBindUi(this));
		this.ac=ac;
	}

}
