package com.appspot.mangolearning.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface LoginServiceAsync {

	void login(String userName, String password, AsyncCallback<User> callback);

}
