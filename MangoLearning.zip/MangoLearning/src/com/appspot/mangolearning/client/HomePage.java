package com.appspot.mangolearning.client;

import java.util.ArrayList;
import java.util.Date;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.Label;

public class HomePage extends Composite {

	private static HomePageUiBinder uiBinder = GWT
			.create(HomePageUiBinder.class);
	
	private AppController ac;
	private ArrayList<GameInfo> gameInfo;
	boolean oneTime=true;
	
	@UiField Label welcomeLabel;
	@UiField Label workoutCompleteLabel;
	@UiField Image checkMark;
	@UiField Label workoutLabel;
	@UiField Label todayGames;
	@UiField Button workoutBtn;
	@UiField Image game1;
	@UiField Image game2;
	@UiField Image game3;

	interface HomePageUiBinder extends UiBinder<Widget, HomePage> {
	}

	public HomePage(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
	}
	
	public void setUpHomePage(User student)
	{

		welcomeLabel.setText("Welcome " + student.getFirstName() + " " + student.getLastName());
		
		Date d = new Date();
		int month = d.getMonth();
		int day = d.getDate();
		String today = month+"/"+day;	
		
		if(student.getDate().equals(today))//WORKOUT DONE
		{
			disableDailyWorkout();
		}
		else{//CREATE WORKOUT
			if(oneTime){
				ac.initDailyWorkoutData();
				oneTime=false;
			}
			gameInfo = ac.getGameList();
			
			game1.setUrl(gameInfo.get(0).getSpritePath());
			game2.setUrl(gameInfo.get(1).getSpritePath());
			game3.setUrl(gameInfo.get(2).getSpritePath());
			workoutCompleteLabel.setVisible(false);
			checkMark.setVisible(false);
		}
	}
	
	@UiHandler("workoutBtn")
	void handleDailyWorkout(ClickEvent e) {
		ac.startDailyWorkout();
	}

	public void disableDailyWorkout(){
		workoutCompleteLabel.setVisible(true);
		checkMark.setVisible(true);
		game1.setVisible(false);
		game2.setVisible(false);
		game3.setVisible(false);
		workoutLabel.setVisible(false);
		workoutBtn.setVisible(false);
		todayGames.setVisible(false);
	}
}
