package com.appspot.mangolearning.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class MangoLearning implements EntryPoint {
	private AbsolutePanel panel2 = new AbsolutePanel();
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		panel2.setSize("1600px", "700px");
		Button loginButton = new Button("Log In");
		loginButton.addStyleName("gwt-loginButton");
		panel2.add(loginButton,1200,15);
		
		TextBox usernameBox = new TextBox(); 
	    TextBox passwordBox = new TextBox();
	    usernameBox.setText("Username");
	    passwordBox.setText("Password");
	    panel2.add(usernameBox, 800, 12);
	    panel2.add(passwordBox, 1000, 12);
	      
		
		Label label = new Label("Mango Learning");
		label.setStyleName("gwt-logoName");
		panel2.add(label, 150, -15);
			
		Label welcome = new Label("WELCOME TO MANGO LEARNING, WHERE THE FUN BEGINS!");
		welcome.setWidth("600px");
		welcome.setStyleName("gwt-welcome");
		panel2.add(welcome,150,130);
		Image image = new Image();
		image.setUrl("http://galpod.files.wordpress.com/2013/07/children-learning-with-computer.jpg");
		image.setHeight("300px");
		image.setWidth("500px");
		panel2.add(image,150,220);
		
		Label register = new Label("Sign Up. It's Always Going to be Free!");
		register.setStyleName("gwt-registerLabel");
		TextBox fName = new TextBox(); 
	    TextBox lName = new TextBox();
	    TextBox userNameR = new TextBox(); 
	    TextBox passwordR = new TextBox();
	    fName.setText("First Name");
	    lName.setText("Last Name");
	    passwordR.setText("Password");
	    userNameR.setText("Username");
	    
	    panel2.add(fName,800,130);
	    panel2.add(lName,990,130);
	    panel2.add(userNameR,800,170);
	    panel2.add(passwordR,800,210);
	    panel2.add(register,800,85);
	    
	    ListBox month = new ListBox();
	    month.addItem("January"); month.addItem("February");month.addItem("March");month.addItem("April");month.addItem("May");month.addItem("June");month.addItem("July");month.addItem("August");month.addItem("September");month.addItem("October");month.addItem("November");month.addItem("December");
	    month.setVisibleItemCount(1);
	    panel2.add(month,800,260);
	    ListBox day = new ListBox();
	    day.addItem("1"); day.addItem("2");day.addItem("3");day.addItem("4");day.addItem("5");day.addItem("6");day.addItem("7");day.addItem("8");day.addItem("9");day.addItem("10");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");day.addItem("1");
	    day.setVisibleItemCount(1);
	    panel2.add(day,900,260);
	    
	    ListBox year = new ListBox();
	    year.setVisibleItemCount(1);
	    year.addItem("2012");year.addItem("2011");year.addItem("2010");year.addItem("2009");year.addItem("2008");year.addItem("2007");year.addItem("2006");year.addItem("2005");year.addItem("2004");year.addItem("2003");year.addItem("2002");year.addItem("2001");year.addItem("2000");year.addItem("1999");year.addItem("2012");year.addItem("2012");year.addItem("2012");year.addItem("2012");year.addItem("2012");year.addItem("2012");year.addItem("2012");
	    panel2.add(year,955,260);
	    
	    RadioButton rb0 = new RadioButton("myRadioGroup", "Male");
	    RadioButton rb1 = new RadioButton("myRadioGroup", "Female");
	    RadioButton rb2 = new RadioButton("myRadioGroup", "Other");
	    panel2.add(rb0,800,300);
	    panel2.add(rb1,850,300);
	    panel2.add(rb2,920,300);
	    
	    Button registerButton = new Button("Register");
	    registerButton.addStyleName("gwt-loginButton");
	    panel2.add(registerButton,800,340);
	    
		RootPanel.get().add(panel2);
	}
}
