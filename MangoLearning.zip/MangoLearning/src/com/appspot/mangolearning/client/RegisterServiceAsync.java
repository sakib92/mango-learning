package com.appspot.mangolearning.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface RegisterServiceAsync {

	void register(User newUser, AsyncCallback<User> callback);

}
