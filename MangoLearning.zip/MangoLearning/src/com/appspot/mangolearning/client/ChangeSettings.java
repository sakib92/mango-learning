package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class ChangeSettings extends Composite {

	private static ChangeSettingsUiBinder uiBinder = GWT
			.create(ChangeSettingsUiBinder.class);

	interface ChangeSettingsUiBinder extends UiBinder<Widget, ChangeSettings> {
	}
	
	private ChangeSettingsServiceAsync changeSettingsSvc = GWT.create(ChangeSettingsService.class);
	private AppController ac;
	@UiField TextBox pass;
	@UiField TextBox retypePass;
	@UiField TextBox fName;
	@UiField TextBox lName;
	@UiField RadioButton male;
	@UiField RadioButton female;
	@UiField Button saveChangesBtn;
	
	public ChangeSettings(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
	}
	
	@UiHandler("saveChangesBtn")
	public void handleSaveChanges(ClickEvent e)
	{
		if(pass.getText().trim().equals("") || retypePass.getText().trim().equals("") || fName.getText().trim().equals("") || lName.getText().trim().equals(""))
		{
			System.out.println("Client: you left something blank");
			return;
		}
		else if(!(pass.getText().equals(retypePass.getText())))
		{
			System.out.println("Client: Passwords dont match");
			return;
		}
		
		if (changeSettingsSvc == null) {
	      changeSettingsSvc = GWT.create(ChangeSettingsService.class);
	    }
		AsyncCallback<User> callback = new AsyncCallback<User>() {
	      public void onFailure(Throwable caught) {
	        // TODO: Do something with errors.
	      }
	
	      public void onSuccess(User result) {
	        ac.setUser(result);
	        ac.setAccInfo();
	        ac.changeScreen(2);
	      }
	    };
	    
	    String gender;
	    if(male.getValue()==true) 
	    	gender = "Male";
	    else 
	    	gender = "Female";
	    
	    User diffSettings = new User(ac.getUser().getUsername(),pass.getText(),fName.getText(),lName.getText(),gender,ac.getUser().getDate());
	    changeSettingsSvc.changeSettings(diffSettings, callback);
	}
	
	public void setUpPage(User u)
	{
		pass.setText(u.getPassword());
		retypePass.setText(u.getPassword());
		fName.setText(u.getFirstName());
		lName.setText(u.getLastName());
		if(u.getGender().equalsIgnoreCase("male")){
			male.setValue(true);
		}else{
			female.setValue(true);
		}
	}
	
	

}
