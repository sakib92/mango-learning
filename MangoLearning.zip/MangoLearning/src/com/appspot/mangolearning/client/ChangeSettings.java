package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

public class ChangeSettings extends Composite {

	private static ChangeSettingsUiBinder uiBinder = GWT
			.create(ChangeSettingsUiBinder.class);

	interface ChangeSettingsUiBinder extends UiBinder<Widget, ChangeSettings> {
	}

	private AppController ac;
	
	public ChangeSettings(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
	}
}
