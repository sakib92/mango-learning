package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class ChangeSettings extends Composite {

	private static ChangeSettingsUiBinder uiBinder = GWT
			.create(ChangeSettingsUiBinder.class);

	interface ChangeSettingsUiBinder extends UiBinder<Widget, ChangeSettings> {
	}
	
	private ChangeSettingsServiceAsync changeSettingsSvc = GWT.create(ChangeSettingsService.class);
	private AppController ac;
	private User changedSetts;
	@UiField TextBox pass;
	@UiField TextBox retypePass;
	@UiField TextBox fName;
	@UiField TextBox lName;
	@UiField RadioButton male;
	
	@UiField Button saveChangesBtn;
	
	public ChangeSettings(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
	}
	
	@UiHandler("saveChangesBtn")
	public void handleSaveChanges(ClickEvent e)
	{
		if(pass.getText().trim().equals("") || retypePass.getText().trim().equals("") || fName.getText().trim().equals("") || lName.getText().trim().equals(""))
		{
			System.out.println("Client: you left something blank");
			return;
		}
		else if(!(pass.getText().equals(retypePass.getText())))
		{
			System.out.println("Client: Passwords dont match");
			return;
		}
		
		if (changeSettingsSvc == null) {
	      changeSettingsSvc = GWT.create(ChangeSettingsService.class);
	    }
		AsyncCallback<Boolean> callback = new AsyncCallback<Boolean>() {
	      public void onFailure(Throwable caught) {
	        // TODO: Do something with errors.
	      }
	
	      public void onSuccess(Boolean result) {
	        ac.setUser(changedSetts);
	        ac.setAccInfo();
	        ac.changeScreen(2);
	      }
	    };
	    
	    String gender;
	    if(male.getValue()==true) 
	    	gender = "Male";
	    else 
	    	gender = "Female";
	    
	    User diffSettings = new User(ac.getUser().getUsername(),pass.getText(),fName.getText(),lName.getText(),gender);
	    changedSetts=diffSettings;
	    changeSettingsSvc.changeSettings(diffSettings, callback);
	}
	
	public void setUpPage(User u)
	{
		fName.setText(u.getFirstName());
		lName.setText(u.getLastName());
	}
	
	

}
