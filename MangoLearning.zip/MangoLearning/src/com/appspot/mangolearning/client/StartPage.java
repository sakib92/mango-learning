package com.appspot.mangolearning.client;

import com.google.gwt.user.client.Window;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.uibinder.client.UiHandler;


public class StartPage extends Composite {

	private static StartPageUiBinder uiBinder = GWT
			.create(StartPageUiBinder.class);
	private AppController ac;

	interface StartPageUiBinder extends UiBinder<Widget, StartPage> {
	}

	@UiField Button loginButton;
	@UiField TextBox userLogin; 
	@UiField TextBox passLogin;
	public StartPage(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
	}
	
	@UiHandler("loginButton")
	void handleLogin(ClickEvent e) {
	  ac.changeScreen(1);
	  ac.displayHomeScreenMenu(true);
	 
	}

}
