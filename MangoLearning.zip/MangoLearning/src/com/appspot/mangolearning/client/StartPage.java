package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;

public class StartPage extends Composite {

	private static StartPageUiBinder uiBinder = GWT
			.create(StartPageUiBinder.class);
	private AppController ac;
	
	  private LoginServiceAsync loginSvc = GWT.create(LoginService.class);
	  private RegisterServiceAsync registerSvc = GWT.create(RegisterService.class);

	interface StartPageUiBinder extends UiBinder<Widget, StartPage> {
	}
	
	User student;
	
	//LOGIN FORMS
	@UiField Button loginButton;
	@UiField TextBox userLogin; 
	@UiField TextBox passLogin;
	
	//REGISTER FORMS
	@UiField TextBox firstName;
	@UiField TextBox lastName;
	@UiField TextBox username;
	@UiField TextBox password;
	@UiField RadioButton maleBtn;
	@UiField RadioButton femaleBtn;
	@UiField Button registerBtn;
	
	public StartPage(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
	}
	
	@UiHandler("loginButton")
	void handleLogin(ClickEvent e) {
	    // Initialize the service proxy.
	    if (loginSvc == null) {
	      loginSvc = GWT.create(LoginService.class);
	    }
	    
	    // Set up the callback object.
	    AsyncCallback<User> callback = new AsyncCallback<User>() {
	      public void onFailure(Throwable caught) {
	    	  System.out.println("Exception thrown");
	      }
	      @Override
	      public void onSuccess(User result) {
	    	 if(result!=null) {
	    		  student = result;
	    		  //parse user name since it is in format: User("mango")
	    		  int i = student.getUsername().indexOf('('); i+=2;
	    		  int k = student.getUsername().indexOf(')'); k-=1;
	    		  String correctUsername = student.getUsername().substring(i,k);
	    		  student.setUsername(correctUsername);
	    		  //change screen and set current student in appController 
	    		  ac.setUser(student);
	    		  ac.setUpHomePage();
	    		  ac.changeScreen(1);
	    		  ac.displayHomeScreenMenu(true);
	    		  System.out.println("Client: Hello " + student.getFirstName()+" " + student.getLastName());
	    	 }
	    	 else{
	    		 System.out.println("Client: User not found");
	    	 }
	      }
	    };   
	    
	    loginSvc.login(userLogin.getText().toLowerCase(),passLogin.getText(), callback);
	}

	@UiHandler("registerBtn")
	void handleRegister(ClickEvent e)
	{
		//REJECT Empty Strings
		if(firstName.getText().trim().equals("") || lastName.getText().trim().equals("") || username.getText().trim().equals("") 
				|| password.getText().trim().equals("") || maleBtn.getText().trim().equals("") || maleBtn.getText().trim().equals(""))
		{
			System.out.println("Client: Empty Field");
			return;
		}
		
		//Get Gender
		String theGender;
		if(maleBtn.getValue())
		{
			theGender = "Male";
		}
		else
		{
			theGender = "Female";
		}
		
		User u = new User(username.getText(), password.getText(), firstName.getText(), lastName.getText(),theGender);
		// Initialize the service proxy.
	    if (registerSvc == null) {
	    	registerSvc = GWT.create(RegisterService.class);
	    }

	    // Set up the callback object.
	    AsyncCallback<User> callback = new AsyncCallback<User>() {
	      public void onFailure(Throwable caught) {
	        // TODO: Do something with errors.
	      }

	      public void onSuccess(User result) {
	        if(result!=null)
	        {
		    	student = result;
		    	ac.changeScreen(1);
	    		ac.displayHomeScreenMenu(true);
		        System.out.println("User created");
	        }
	        else{
	        	System.out.println("Client: User Already Exists");
	        }
	      }
	    };

	    // Make the call to the service.
	    registerSvc.register(u, callback);
		
	}
	
}
