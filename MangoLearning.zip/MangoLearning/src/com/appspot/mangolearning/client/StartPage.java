package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.BlurEvent;
import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.FocusEvent;
import com.google.gwt.event.dom.client.FocusHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;

public class StartPage extends Composite {

	private static StartPageUiBinder uiBinder = GWT
			.create(StartPageUiBinder.class);
	private AppController ac;
	
	  private LoginServiceAsync loginSvc = GWT.create(LoginService.class);
	  private RegisterServiceAsync registerSvc = GWT.create(RegisterService.class);

	interface StartPageUiBinder extends UiBinder<Widget, StartPage> {
	}
	
	User student;
	
	//LOGIN FORMS
	@UiField Button loginButton;
	@UiField TextBox userLogin; 
	@UiField PasswordTextBox passLogin;
	
	//REGISTER FORMS
	@UiField TextBox firstName;
	@UiField TextBox lastName;
	@UiField TextBox username;
	@UiField TextBox password;
	@UiField RadioButton maleBtn;
	@UiField RadioButton femaleBtn;
	@UiField Button registerBtn;
	
	
	public StartPage(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
		setupTextFieldDefaults();
	}
	


	@UiHandler("loginButton")
	void handleLogin(ClickEvent e) {
	    // Initialize the service proxy.
	    if (loginSvc == null) {
	      loginSvc = GWT.create(LoginService.class);
	    }
	    // Set up the callback object.
	    AsyncCallback<User> callback = new AsyncCallback<User>() {
	      public void onFailure(Throwable caught) {
	    	  System.out.println("Exception thrown");
	      }
	      @Override
	      public void onSuccess(User result) {
	    	 if(result!=null) {
	    		  student = result;
	    		  //parse user name since it is in format: User("mango")
	    		  int i = student.getUsername().indexOf('('); i+=2;
	    		  int k = student.getUsername().indexOf(')'); k-=1;
	    		  String correctUsername = student.getUsername().substring(i,k);
	    		  student.setUsername(correctUsername);
	    		  //change screen and set current student in appController 
	    		  ac.setUser(student);
	    		  ac.setUpHomePage();
	    		  ac.changeScreen(1);
	    		  ac.displayHomeScreenMenu(true);
	    		  System.out.println("Client: Hello " + student.getFirstName()+" " + student.getLastName());
	    	 }
	    	 else{
	    		 System.out.println("Client: User not found");
	    	 }
	      }
	    };   
	    
	    loginSvc.login(userLogin.getText().toLowerCase(),passLogin.getText(), callback);
	}

	@UiHandler("registerBtn")
	void handleRegister(ClickEvent e)
	{

		if(!correctRegisterFormat())
		{
			return;
		}
		//Get Gender
		String theGender;
		if(maleBtn.getValue())
		{
			theGender = "Male";
		}
		else
		{
			theGender = "Female";
		}
		
		User u = new User(username.getText().toLowerCase(), password.getText(), firstName.getText(), lastName.getText(),theGender,"-1");
		// Initialize the service proxy.
	    if (registerSvc == null) {
	    	registerSvc = GWT.create(RegisterService.class);
	    }

	    // Set up the callback object.
	    AsyncCallback<User> callback = new AsyncCallback<User>() {
	      public void onFailure(Throwable caught) {
	        // TODO: Do something with errors.
	      }

	      public void onSuccess(User result) {
	        if(result!=null)
	        {
		    	ac.setUser(result);
		    	ac.setUpHomePage();
		    	ac.changeScreen(1);
	    		ac.displayHomeScreenMenu(true);
		        System.out.println("User created");
	        }
	        else{
	        	System.out.println("Client: User Already Exists");
	        }
	      }
	    };

	    // Make the call to the service.
	    registerSvc.register(u, callback);
		
	}
	
	public void setUpStartPage()
	{
		userLogin.setText("Username");
		passLogin.setText("Password");
		username.setText("Username");
		password.setText("Password");
		firstName.setText("First Name");
		lastName.setText("Last Name");
		maleBtn.setValue(true);
	}	
	
	private boolean correctRegisterFormat()
	{
		//REJECT Empty Strings
		if(firstName.getText().trim().equals("") || lastName.getText().trim().equals("") || username.getText().trim().equals("") 
				|| password.getText().trim().equals("") || maleBtn.getText().trim().equals("") || maleBtn.getText().trim().equals(""))
		{
			System.out.println("Client: Empty Field");
			return false;
		}
		else if(password.getText().length()<5 || username.getText().length()<5)
		{
			System.out.println("Client: Password or username too short");
			return false;
		}
		else
		{
			return true;
		}
	}
	
	private void setupTextFieldDefaults() {
		userLogin.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				if(userLogin.getText().equalsIgnoreCase("Username"))
					userLogin.setText("");
			}
		});
		
		passLogin.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				if(passLogin.getText().equalsIgnoreCase("password"))
					passLogin.setText("");
			}
		});
		firstName.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				if(firstName.getText().equalsIgnoreCase("First Name"))
					firstName.setText("");
			}
		});
		
		lastName.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				if(lastName.getText().equalsIgnoreCase("Last Name"))
					lastName.setText("");
			}
		});
		
		username.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				if(username.getText().equalsIgnoreCase("Username"))
					username.setText("");
			}
		});
		
		password.addFocusHandler(new FocusHandler() {
			
			@Override
			public void onFocus(FocusEvent event) {
				if(password.getText().equalsIgnoreCase("Password"))
					password.setText("");
			}
		});
		
		userLogin.addBlurHandler(new BlurHandler() {
			
			@Override
			public void onBlur(BlurEvent event) {
				if(userLogin.getText().trim().equals(""))
				userLogin.setText("Username");
				
			}
		});
		
		passLogin.addBlurHandler(new BlurHandler() {
			
			@Override
			public void onBlur(BlurEvent event) {
				if(passLogin.getText().trim().equals(""))
				passLogin.setText("Password");
				
			}
		});
		
		firstName.addBlurHandler(new BlurHandler() {
			
			@Override
			public void onBlur(BlurEvent event) {
				if(firstName.getText().trim().equals(""))
				firstName.setText("First Name");
				
			}
		});
		
		lastName.addBlurHandler(new BlurHandler() {
			
			@Override
			public void onBlur(BlurEvent event) {
				if(lastName.getText().trim().equals(""))
				lastName.setText("Last Name");
				
			}
		});
		
		password.addBlurHandler(new BlurHandler() {
			
			@Override
			public void onBlur(BlurEvent event) {
				if(password.getText().trim().equals(""))
				password.setText("Password");
				
			}
		});
		
		username.addBlurHandler(new BlurHandler() {
			
			@Override
			public void onBlur(BlurEvent event) {
				if(username.getText().trim().equals(""))
				username.setText("Username");
				
			}
		});
	}
}
