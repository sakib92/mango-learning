package com.appspot.mangolearning.client;

import com.google.gwt.user.client.Window;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.uibinder.client.UiHandler;


public class StartPage extends Composite {

	private static StartPageUiBinder uiBinder = GWT
			.create(StartPageUiBinder.class);

	interface StartPageUiBinder extends UiBinder<Widget, StartPage> {
	}

	@UiField Button login;
	
	public StartPage() {
		initWidget(uiBinder.createAndBindUi(this));
	}
	
	@UiHandler("login")
	void handleLogin(ClickEvent e) {
	  RootPanel.get("navBar").clear();
	}
	
	

}
