package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.dom.client.MouseOverEvent;
import com.google.gwt.event.dom.client.MouseOverHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class GamesPage extends Composite {

	private static GamesPageUiBinder uiBinder = GWT
			.create(GamesPageUiBinder.class);

	interface GamesPageUiBinder extends UiBinder<Widget, GamesPage> {
	}
	
	private AppController ac;
	@UiField Button allGamesBtn;
	@UiField Button mathGamesBtn;
	@UiField Button scienceGamesBtn;
	
	@UiField Label gameHeader;
	
	@UiField VerticalPanel mathGamesList;
	@UiField Image additionMadness;
	@UiField Image subtractionFrenzy;
	@UiField Image multiplicationStorm;
	@UiField Image divisionDisaster;
	@UiField Image chalkboardChallanger;
	
	
	public GamesPage(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac=appCont;
		setUpSpriteHandlers();
		
	}
	
	@UiHandler("allGamesBtn")
	void handleViewAllGames(ClickEvent e) {
		gameHeader.setText("All Games");
		mathGamesList.setVisible(true);
	}
	
	@UiHandler("mathGamesBtn")
	void handleMathGames(ClickEvent e) {
		gameHeader.setText("Math Games");
		mathGamesList.setVisible(true);
	}
	
	@UiHandler("scienceGamesBtn")
	void handleScienceGames(ClickEvent e) {
		gameHeader.setText("Science Games");
		mathGamesList.setVisible(false);
	}
	
	private void setUpSpriteHandlers()
	{
		additionMadness.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				ac.startGame("minigames/Addition/index.html","Addition Madness");
			}
		});
		
		additionMadness.addMouseOverHandler(new MouseOverHandler() {
		
		@Override
		public void onMouseOver(MouseOverEvent event) {
			additionMadness.setUrl("gameSprites/addHover.png");;
			
		}
		});
		
		additionMadness.addMouseOutHandler(new MouseOutHandler() {
			
			@Override
			public void onMouseOut(MouseOutEvent event) {
				additionMadness.setUrl("gameSprites/add.png");;
				
			}
		});
		
		subtractionFrenzy.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				ac.startGame("minigames/Subtraction/index.html","Subtraction Frenzy");
			}
		});
		
		subtractionFrenzy.addMouseOverHandler(new MouseOverHandler() {
			
		@Override
		public void onMouseOver(MouseOverEvent event) {
			subtractionFrenzy.setUrl("gameSprites/subtractHover.png");;
			
		}
		});
		
		subtractionFrenzy.addMouseOutHandler(new MouseOutHandler() {
			
			@Override
			public void onMouseOut(MouseOutEvent event) {
				subtractionFrenzy.setUrl("gameSprites/subtract.png");;
				
			}
		});
		
		multiplicationStorm.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				ac.startGame("minigames/Multiplication/index.html","Multiplication Storm");
			}
		});
		
		multiplicationStorm.addMouseOverHandler(new MouseOverHandler() {
			
			@Override
			public void onMouseOver(MouseOverEvent event) {
				multiplicationStorm.setUrl("gameSprites/multiplyHover.png");;
				
			}
		});
			
		multiplicationStorm.addMouseOutHandler(new MouseOutHandler() {
				
				@Override
				public void onMouseOut(MouseOutEvent event) {
					multiplicationStorm.setUrl("gameSprites/multiply.png");;
					
				}
			});

		divisionDisaster.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				ac.startGame("minigames/Division/index.html","Division Disaster");
			}
		});
		
		divisionDisaster.addMouseOverHandler(new MouseOverHandler() {
			
			@Override
			public void onMouseOver(MouseOverEvent event) {
				divisionDisaster.setUrl("gameSprites/divisionHover.png");;
				
			}
		});
			
		divisionDisaster.addMouseOutHandler(new MouseOutHandler() {
				
				@Override
				public void onMouseOut(MouseOutEvent event) {
					divisionDisaster.setUrl("gameSprites/division.png");;
					
				}
			});
		
		chalkboardChallanger.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
			ac.startGame("minigames/Chalkboard/index.html","Chalkboard Challenger");
		}
		});	
		
		chalkboardChallanger.addMouseOverHandler(new MouseOverHandler() {
		
		@Override
		public void onMouseOver(MouseOverEvent event) {
			chalkboardChallanger.setUrl("gameSprites/chalkboardHover.png");;
			
		}
		});
		
		chalkboardChallanger.addMouseOutHandler(new MouseOutHandler() {
			
			@Override
			public void onMouseOut(MouseOutEvent event) {
				chalkboardChallanger.setUrl("gameSprites/chalkboard.png");;
				
			}
		});
	}

}
