package com.appspot.mangolearning.client;

import java.util.ArrayList;
import java.util.Collections;
import com.google.gwt.user.client.Random;
import com.google.gwt.user.client.ui.DeckPanel;
import com.google.gwt.user.client.ui.RootPanel;

public class AppController {
		
	User student;
	ArrayList<GameInfo> gameList;
	public int dailyWorkoutGame;
	
	DeckPanel panel = new DeckPanel(); //This contains all the screens
	MenuBar menu = new MenuBar(this);		//menu bar for home screen and onwards
	StartPage startPage = new StartPage(this); //This has its own menu bar
	HomePage homePage = new HomePage(this);
	AccountPage accPage = new AccountPage(this);
	ChangeSettings changeSettings = new ChangeSettings(this);
	GamesPage gamePage = new GamesPage(this);
	AchievementPage achievementPage = new AchievementPage(this);
	GameInProgress game = null; //only created when we need to play a game. Removed when leaving the game
	FullMembershipPage member = new FullMembershipPage(this);
	
	public AppController(){
		panel.add(startPage);      //0: START PAGE
		panel.add(homePage);       //1: HOME PAGE	
		panel.add(accPage);        //2: ACCOUNT PAGE
		panel.add(changeSettings); //3: CHANGE SETTINGS
		panel.add(gamePage); 	   //4: GAMES PAGE
		panel.add(achievementPage);//5: ACHIEVEMENT PAGE		  
		panel.add(member);
		panel.showWidget(0);	   //DISPLAY THE START PAGE WHEN APP LOADS FOR FIRST TIME
	}
	
	public void initDailyWorkoutData() {
		dailyWorkoutGame=0;
		gameList = new ArrayList<GameInfo>();
		gameList.add(new GameInfo("Addition Madness", "gameSprites/add.png", "minigames/Addition/index.html"));
		gameList.add(new GameInfo("Subtraction Frenzy", "gameSprites/subtract.png", "minigames/Subtraction/index.html"));
		gameList.add(new GameInfo("Multiplication Storm", "gameSprites/multiply.png", "minigames/Multiplication/index.html"));
		gameList.add(new GameInfo("Division Disaster", "gameSprites/division.png", "minigames/Division/index.html"));
		gameList.add(new GameInfo("Chalkboard Challenger", "gameSprites/chalkboard.png", "minigames/Chalkboard/index.html"));
		//SHUFFLE ARRAY
		for(int index = 0; index < gameList.size(); index += 1) {  
			    Collections.swap(gameList, index, Random.nextInt(gameList.size()));  
			 }  
	}

	public void setUser(User student) {
		this.student = student;
	}

	public User getUser() {
		return student;
	}
	public ArrayList<GameInfo> getGameList()
	{
		return gameList;
	}
	public DeckPanel getPanel()
	{
		return panel;
	}

	public void changeScreen(int i){
		panel.showWidget(i);
	}

	public void setAccInfo(){
		accPage.setInfo(student);
	}
	
	public void displayHomeScreenMenu(boolean val) {
		if (val)
			RootPanel.get().add(menu);
		else
			RootPanel.get().remove(menu);
	}
	
	public void setUpChangeSettingsPage(){
		changeSettings.setUpPage(student);
	}
	
	public void setUpHomePage(){
		homePage.setUpHomePage(student);
	}
	
	public void setUpStartPage() {
		homePage.oneTime = true;
		startPage.setUpStartPage();
	}
	
	public void startDailyWorkout() {
		game = new GameInProgress(this);
		game.dailyWorkoutSetup(dailyWorkoutGame, gameList);
		panel.add(game);
		panel.showWidget(7);
	}

	//Start single game from game list page
	public void startGame(String path, String gameName) {
		game = new GameInProgress(this);
		game.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", path);
		game.singleGameSetup(gameName);
		panel.add(game);
		panel.showWidget(7);
	}

	public void removeGame() {
		if (game != null) {
			panel.remove(7);
			game = null;
		}
	}
	
	//For logout
	public void reset(){
		panel.clear();
		startPage = new StartPage(this); //This has its own menu bar
		homePage = new HomePage(this);
		accPage = new AccountPage(this);
		changeSettings = new ChangeSettings(this);
		gamePage = new GamesPage(this);
		achievementPage = new AchievementPage(this);
		member = new FullMembershipPage(this);
		game = null;
		panel.add(startPage);      //0: START PAGE
		panel.add(homePage);       //1: HOME PAGE	
		panel.add(accPage);        //2: ACCOUNT PAGE
		panel.add(changeSettings); //3: CHANGE SETTINGS
		panel.add(gamePage); 	   //4: GAMES PAGE
		panel.add(achievementPage);//5: ACHIEVEMENT PAGE
		panel.add(member);
		dailyWorkoutGame = 0;
	}

}
