package com.appspot.mangolearning.client;

import com.google.gwt.user.client.ui.DeckPanel;
import com.google.gwt.user.client.ui.RootPanel;

public class AppController {
	
	DeckPanel panel = new DeckPanel(); //This contains all the screens
	MenuBar menu = new MenuBar(this);		//menu bar for home screen and onwards
	
	StartPage startPage = new StartPage(this); //This as its own menu bar
	HomePage homePage = new HomePage(this);
	AccountPage accPage = new AccountPage(this);
	
	public AppController(){
		panel.add(startPage);    //0: START PAGE
		panel.add(homePage);     //1: HOME PAGE	
		panel.add(accPage);      //2: ACCOUNT PAGE
		panel.showWidget(0);	 //DISPLAY THE START PAGE WHEN APP LOADS FOR FIRST TIME
		RootPanel.get().add(panel); //ADD START PAGE TO BODY
		
	}
	
	public DeckPanel getPanel()
	{
		return panel;
	}
	
	public void changeScreen(int i){
		panel.showWidget(i);
	}
	
	public void displayHomeScreenMenu(boolean val)
	{
		if(val)	RootPanel.get().add(menu);
		else 	RootPanel.get().remove(menu);
	}
	
}
