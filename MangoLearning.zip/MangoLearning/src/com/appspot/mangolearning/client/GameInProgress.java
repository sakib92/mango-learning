package com.appspot.mangolearning.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class GameInProgress extends Composite {

	private static GameInProgressUiBinder uiBinder = GWT
			.create(GameInProgressUiBinder.class);

	interface GameInProgressUiBinder extends UiBinder<Widget, GameInProgress> {
	}
	
	private ChangeSettingsServiceAsync changeSettingsSvc = GWT.create(ChangeSettingsService.class);
	private RequestScoresServiceAsync requestScoresSvc = GWT.create(RequestScoresService.class);
	
	AppController ac;
	private ArrayList<Integer> gameScores;
	@UiField
	Button nextGame;
	@UiField
	Label gameLabel;
	@UiField
	Button submitScore;
	@UiField
	Button completeWorkout;
	@UiField 
	Image gamesCompletedIcon;
	@UiField
	Label score1Label;
	@UiField
	Label score2Label;
	@UiField
	Label score3Label;
	
	public GameInProgress(AppController ac) {
		initWidget(uiBinder.createAndBindUi(this));
		this.ac = ac;
		gameScores = new ArrayList<Integer>();
	}

	public void singleGameSetup(String gameName) {
		gameLabel.setText(gameName);
		submitScore.setVisible(true);
		nextGame.setVisible(false);
		completeWorkout.setVisible(false);
		gamesCompletedIcon.setVisible(false);
		
		gameName = gameName.replaceAll("\\s", "");
		// Set up the callback object.
	    AsyncCallback<String> callback = new AsyncCallback<String>() {
	      public void onFailure(Throwable caught) {
	    	  
	      }
	      @Override
	      public void onSuccess(String bigString) {
	    	if(bigString!=null){
	    		parseScores(bigString);
	    	}else{ //This means that null is stored in the datastore for the scores
	    		gameScores.add(0);
	    		gameScores.add(0);
	    		gameScores.add(0);
	    	}	  	
	    	score1Label.setText("1. "+ gameScores.get(0));
	    	score2Label.setText("2. "+ gameScores.get(1));
	    	score3Label.setText("3. "+ gameScores.get(2));
	      }
	    };   
	   requestScoresSvc.getScores(gameName, ac.getUser().getUsername(), callback);
	}
	
	void parseScores(String scoreString){
		String score1;
		String score2;
		String score3;
	
		int bar1 = scoreString.indexOf('|');
		score1 = scoreString.substring(0, bar1);
		scoreString = scoreString.substring(bar1+1);
		int bar2 = scoreString.indexOf('|');
		score2 = scoreString.substring(0,bar2);
		scoreString = scoreString.substring(bar2+1);
		int bar3 = scoreString.indexOf('|');
		score3 = scoreString.substring(bar3+1);
		
		gameScores.add(Integer.parseInt(score1));
		gameScores.add(Integer.parseInt(score2));
		gameScores.add(Integer.parseInt(score3));
		Collections.sort(gameScores, Collections.reverseOrder());
	}
	
	public void dailyWorkoutSetup(int gameNumber, ArrayList<GameInfo> gameInfo)
	{
		AsyncCallback<String> callback = new AsyncCallback<String>() {
		      public void onFailure(Throwable caught) {
		    	  
		      }
		      @Override
		      public void onSuccess(String bigString) {
		    	if(bigString!=null){
		    		parseScores(bigString);
		    	}else{ //This means that null is stored in the datastore for the scores
		    		gameScores.add(0);
		    		gameScores.add(0);
		    		gameScores.add(0);
		    	}	  	
		    	score1Label.setText("1. "+ gameScores.get(0));
		    	score2Label.setText("2. "+ gameScores.get(1));
		    	score3Label.setText("3. "+ gameScores.get(2));
		      }
		    };   
		
		gameLabel.setText("Daily Workout");
		submitScore.setVisible(false);
		if(gameNumber == 0){
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", gameInfo.get(0).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame1.png");
			completeWorkout.setVisible(false);
		}else if(gameNumber==1){
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", gameInfo.get(1).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame2.png");
			completeWorkout.setVisible(false);
		}else{
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", gameInfo.get(2).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame3.png");
			completeWorkout.setVisible(true);
			nextGame.setVisible(false);
		}
		requestScoresSvc.getScores(gameInfo.get(gameNumber).getName().replaceAll("\\s", ""), ac.getUser().getUsername(), callback);
	}
	
	@UiHandler("nextGame")
	void handleNextGameBtn(ClickEvent e) {
		ac.dailyWorkoutGame+=1;
		
		if(ac.dailyWorkoutGame==1){
		this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", ac.getGameList().get(1).getGamePath());
		gamesCompletedIcon.setUrl("images/onGame2.png");
		}else{
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", ac.getGameList().get(2).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame3.png");
			nextGame.setVisible(false);
			completeWorkout.setVisible(true);
		}
	}
	
	@UiHandler("completeWorkout")
	void handleCompleteWorkoutBtn(ClickEvent e) {
		
		if (changeSettingsSvc == null) {
		      changeSettingsSvc = GWT.create(ChangeSettingsService.class);
		    }
			AsyncCallback<User> callback = new AsyncCallback<User>() {
		      public void onFailure(Throwable caught) {
		        // TODO: Do something with errors.
		      }
		
		      public void onSuccess(User result) {
		  		ac.homePage.disableDailyWorkout();
		  		ac.removeGame();
				ac.changeScreen(1);
				
		      }
		    };
		
	    Date d = new Date();
		int month = d.getMonth();
		int day = d.getDate();
		String today = month+"/"+day;	 
			
		ac.getUser().setDate(today);
		User diffDate = new User(ac.getUser().getUsername(),ac.getUser().getPassword(),ac.getUser().getFirstName(),ac.getUser().getLastName(),ac.getUser().getGender(),ac.getUser().getDate());
		changeSettingsSvc.changeSettings(diffDate, callback);
	}
	
	@UiHandler("submitScore")
	void handleSubmitScoreBtn(ClickEvent e) {
		
	}
}
