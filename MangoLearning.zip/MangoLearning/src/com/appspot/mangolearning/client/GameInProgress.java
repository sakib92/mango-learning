package com.appspot.mangolearning.client;

import java.util.ArrayList;
import java.util.Date;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class GameInProgress extends Composite {

	private static GameInProgressUiBinder uiBinder = GWT
			.create(GameInProgressUiBinder.class);

	interface GameInProgressUiBinder extends UiBinder<Widget, GameInProgress> {
	}
	
	private ChangeSettingsServiceAsync changeSettingsSvc = GWT.create(ChangeSettingsService.class);
	AppController ac;
	@UiField
	Button nextGame;
	@UiField
	Label gameLabel;
	@UiField
	Button completeWorkout;
	@UiField Image gamesCompletedIcon;

	public GameInProgress(AppController ac) {
		initWidget(uiBinder.createAndBindUi(this));
		this.ac = ac;
	}

	public void singleGameSetup(String gameName) {
		gameLabel.setText(gameName);
		nextGame.setVisible(false);
		completeWorkout.setVisible(false);
		gamesCompletedIcon.setVisible(false);
	}
	
	public void dailyWorkoutSetup(int gameNumber, ArrayList<GameInfo> gameInfo)
	{
		gameLabel.setText("Daily Workout");
		if(gameNumber == 0){
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", gameInfo.get(0).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame1.png");
			completeWorkout.setVisible(false);
		}else if(gameNumber==1){
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", gameInfo.get(1).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame2.png");
			completeWorkout.setVisible(false);
		}else{
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", gameInfo.get(2).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame3.png");
			completeWorkout.setVisible(true);
			nextGame.setVisible(false);
		}
	}
	
	@UiHandler("nextGame")
	void handleNextGameBtn(ClickEvent e) {
		ac.dailyWorkoutGame+=1;
		
		if(ac.dailyWorkoutGame==1){
		this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", ac.getGameList().get(1).getGamePath());
		gamesCompletedIcon.setUrl("images/onGame2.png");
		}else{
			this.getElement().getElementsByTagName("iframe").getItem(0).setAttribute("src", ac.getGameList().get(2).getGamePath());
			gamesCompletedIcon.setUrl("images/onGame3.png");
			nextGame.setVisible(false);
			completeWorkout.setVisible(true);
		}
	}
	
	@UiHandler("completeWorkout")
	void handleCompleteWorkoutBtn(ClickEvent e) {
		
		if (changeSettingsSvc == null) {
		      changeSettingsSvc = GWT.create(ChangeSettingsService.class);
		    }
			AsyncCallback<User> callback = new AsyncCallback<User>() {
		      public void onFailure(Throwable caught) {
		        // TODO: Do something with errors.
		      }
		
		      public void onSuccess(User result) {
		  		ac.homePage.disableDailyWorkout();
		  		ac.removeGame();
				ac.changeScreen(1);
				
		      }
		    };
		
	    Date d = new Date();
		int month = d.getMonth();
		int day = d.getDate();
		String today = month+"/"+day;	 
			
		ac.getUser().setDate(today);
		User diffDate = new User(ac.getUser().getUsername(),ac.getUser().getPassword(),ac.getUser().getFirstName(),ac.getUser().getLastName(),ac.getUser().getGender(),ac.getUser().getDate());
		changeSettingsSvc.changeSettings(diffDate, callback);
	}
}
