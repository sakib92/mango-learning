package com.appspot.mangolearning.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface ChangeSettingsServiceAsync {

	void changeSettings(User u, AsyncCallback<Boolean> callback);

}
