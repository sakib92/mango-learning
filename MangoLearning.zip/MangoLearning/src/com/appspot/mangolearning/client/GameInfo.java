package com.appspot.mangolearning.client;

public class GameInfo {
	
	private String name;
	private String spritePath;
	private String gamePath;
	
	public GameInfo(String name, String spritePath, String gamePath)
	{
		this.name = name;
		this.spritePath = spritePath;
		this.gamePath = gamePath;	
	}
	
	public String getSpritePath() {
		return spritePath;
	}
	public void setSpritePath(String spritePath) {
		this.spritePath = spritePath;
	}
	public String getGamePath() {
		return gamePath;
	}
	public void setGamePath(String gamePath) {
		this.gamePath = gamePath;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
