package com.appspot.mangolearning.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

public class AccountPage extends Composite {

	private static AccountPageUiBinder uiBinder = GWT
			.create(AccountPageUiBinder.class);
	
	AppController ac;

	interface AccountPageUiBinder extends UiBinder<Widget, AccountPage> {
	}

	public AccountPage(AppController appCont) {
		initWidget(uiBinder.createAndBindUi(this));
		ac = appCont;
	}

}
