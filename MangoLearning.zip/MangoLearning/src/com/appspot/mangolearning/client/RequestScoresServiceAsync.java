package com.appspot.mangolearning.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface RequestScoresServiceAsync {

	void getScores(String property, String username, AsyncCallback<String> callback);

}
