package com.appspot.mangolearning.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;


@RemoteServiceRelativePath("requestScores")
public interface RequestScoresService extends RemoteService {
	
	String getScores(String property, String username);

}
